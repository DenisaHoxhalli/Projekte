document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const error = document.getElementById("error");
  
    error.classList.remove("success");
    error.style.animation = "none";
    void error.offsetWidth; // hack për me rifresku animacionin
    error.style.animation = null;
  
    if (name.length < 3) {
      error.textContent = "Emri duhet të ketë të paktën 3 karaktere.";
      return;
    }
  
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      error.textContent = "Email-i nuk është në formatin korrekt.";
      return;
    }
  
    if (password.length < 8) {
      error.textContent = "Fjalëkalimi duhet të ketë të paktën 8 karaktere.";
      return;
    }
  
    if (password !== confirmPassword) {
      error.textContent = "Fjalëkalimi dhe konfirmimi nuk përputhen.";
      return;
    }
  
    error.textContent = "Regjistrimi u krye me sukses!";
    error.classList.add("success");
  });
  